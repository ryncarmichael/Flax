tell application "BBEdit"
	if (count of documents) is 0 then
		display dialog "BBEdit has no open documents." buttons {"OK"} default button "OK"
		return
	end if
	
	set currentDocument to front document
	
	-- Save the front document before continuing.
	try
		save currentDocument
	on error errorMessage number errorNumber
		display dialog �
			"BBEdit could not save the front document." & return & return & �
			errorMessage buttons {"OK"} default button "OK"
		return
	end try
	
	-- Get the document's file after saving.
	try
		set documentFile to (file of currentDocument) as alias
	on error
		display dialog �
			"The front document has not been saved, so it has no filename or path." buttons {"OK"} default button "OK"
		return
	end try
end tell

-- Get the document's full POSIX path.
set documentPath to POSIX path of documentFile

-- Get the containing folder and simple filename.
set documentFolder to do shell script �
	"/usr/bin/dirname " & quoted form of documentPath

set simpleFilename to do shell script �
	"/usr/bin/basename " & quoted form of documentPath

-- Only run for files whose extension is .flax or .eflax.
ignoring case
	if (simpleFilename does not end with ".flax") and �
		(simpleFilename does not end with ".eflax") then
		
		display dialog �
			"This script only runs for files with the .flax or .eflax extension." & return & return & �
			"Current file: " & simpleFilename �
			buttons {"OK"} default button "OK"
		return
	end if
end ignoring

-- Alternatively, specify an absolute path.
set executablePath to "runflax"

-- Change to the document's folder, then run:
-- ./runflax filename.flax -I
set shellCommand to �
	"cd " & quoted form of documentFolder & �
	" && " & quoted form of executablePath & �
	" " & quoted form of simpleFilename & �
	" -I"

tell application "Terminal"
	activate
	do script shellCommand
end tell
