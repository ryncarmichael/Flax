tell application "BBEdit"
	try
		save every document
	on error errorMessage number errorNumber
		display dialog "The documents were not all saved." & return & return & errorMessage �
			buttons {"OK"} default button "OK"
		return
	end try
end tell

tell application "Terminal"
	activate
	do script "cipher ~/Documents/Coding/odin/flax/libs/flax.lib ~/Documents/Coding/odin/flax/libs/flax.elib"
end tell

