tell application "BBEdit"
	if (count of documents) is 0 then
		display dialog "BBEdit has no open documents." buttons {"OK"} default button "OK"
		return
	end if
	
	-- Save all open documents first.
	try
		save every document
	on error errorMessage number errorNumber
		display dialog "The documents were not all saved." & return & return & errorMessage �
			buttons {"OK"} default button "OK"
		return
	end try
	
	set currentDocument to front document
	
	try
		set documentFile to (file of currentDocument) as alias
	on error
		display dialog �
			�
				"The front document has not been saved, so its directory cannot be determined." buttons {"OK"} default button "OK"
		return
	end try
end tell

-- Get the full POSIX path of the document.
set documentPath to POSIX path of documentFile

-- Get the directory containing the document.
set documentFolder to do shell script �
	"/usr/bin/dirname " & quoted form of documentPath

-- Run ./make in the document's directory.
set shellCommand to �
	"cd " & quoted form of documentFolder & �
	" && ./make"

tell application "Terminal"
	activate
	do script shellCommand
end tell
